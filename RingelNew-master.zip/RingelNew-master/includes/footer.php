<!-- Footer -->

<footer class="container-fluid bg-4 text-center navbar navbar-default">
<br>  <p>Sponsered By <a href="../index.html">www.RingelWeb.com</a></p>
</footer>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>

